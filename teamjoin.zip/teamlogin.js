
function password_check(myform) {
  var pw = document.myform.pw.value;
  var pw_check = document.myform.pw_check.value;
  if (pw != pw_check) {
    document.getElementById("same").innerHTML = "비밀번호 값이 일치하지 않습니다.";
    myform.pw.value = "";
    myform.pw_check.value = "";
    myform.pw.focus();
  }
  else {
    document.getElementById('same').innerHTML = ' 비밀번호 값이 일치합니다.';
  }
}

function emailauto(e_addr) {
  var mail = "";
  if (e_addr.options[0].selected) {
    mail = "";
  }
  else {
    mail = e_addr.value
  }
  myform.email2.value = mail;
}

function out() {
  var id = document.myform.id.value;
  var pw = document.myform.pw.value;
  var pw_check = document.myform.pw_check.value;
  var name = document.myform.name.value;
  var nick = document.myform.nick.value;
  var year = document.myform.year.value;
  var month = document.myform.month.value;
  var day = document.myform.day.value;
  var postcode = document.myform.postcode.value;
  var addr1 = document.myform.addr1.value;
  var addr2 = document.myform.addr2.value;
  var addr3 = document.myform.addr3.value;
  var phon1 = document.myform.phon1.value;
  var phon2 = document.myform.phon2.value;
  var phon3 = document.myform.phon3.value;
  var sms_agree = document.myform.sms_agree.value;
  var email1 = document.myform.email1.value;
  var email2 = document.myform.email2.value;
  var email_agree = document.myform.email_agree.value;
  var agree1 = document.myform.agree1.checked;
  var agree2 = document.myform.agree2.checked;



  if (id == "") {
    alert("아이디를 써주세요");
    return;
  }


  if (pw == "") {
    alert("비밀번호를 써주세요");
    return;
  }

  if (pw_check == "") {
    alert("비밀번호 확인을 써주세요");
    return;
  }

  if (name == "") {
    alert("이름 써주세요");
    return;
  }

  if (nick == "") {
    alert("닉네임을 써주세요");
    return;
  }

  if (year == "" || month == "" || day == "") {
    alert("생년월일을 써주세요");
    return;
  }

  if (phon2 == "" || phon3 == "") {
    alert("휴대폰 번호를 써주세요");
    return;
  }

  if (postcode == "" || addr1 == "" || addr2 == "" || addr3 == "") {
    alert("주소를 써주세요");
    return;
  }

  if (email1 == "" || email2 == "") {
    alert("이메일을 써주세요");
    return;
  }

  if (agree1 == false) {
    alert("이용정보동의를 체크해주세요");
    return;
  }

  if (agree2 == false) {
    alert("개인정보이용동의를 체크해주세요");
    return;
  }


  myform.submit();
}

function sample6_execDaumPostcode() {
  new daum.Postcode({
    oncomplete: function (data) {
      // 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.

      // 각 주소의 노출 규칙에 따라 주소를 조합한다.
      // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
      var addr = ''; // 주소 변수
      var extraAddr = ''; // 참고항목 변수

      //사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
      if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우
        addr = data.roadAddress;
      } else { // 사용자가 지번 주소를 선택했을 경우(J)
        addr = data.jibunAddress;
      }

      // 사용자가 선택한 주소가 도로명 타입일때 참고항목을 조합한다.
      if (data.userSelectedType === 'R') {
        // 법정동명이 있을 경우 추가한다. (법정리는 제외)
        // 법정동의 경우 마지막 문자가 "동/로/가"로 끝난다.
        if (data.bname !== '' && /[동|로|가]$/g.test(data.bname)) {
          extraAddr += data.bname;
        }
        // 건물명이 있고, 공동주택일 경우 추가한다.
        if (data.buildingName !== '' && data.apartment === 'Y') {
          extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
        }
        // 표시할 참고항목이 있을 경우, 괄호까지 추가한 최종 문자열을 만든다.
        if (extraAddr !== '') {
          extraAddr = ' (' + extraAddr + ')';
        }
        // 조합된 참고항목을 해당 필드에 넣는다.
        document.getElementById("sample6_extraAddress").value = extraAddr;

      } else {
        document.getElementById("sample6_extraAddress").value = '';
      }

      // 우편번호와 주소 정보를 해당 필드에 넣는다.
      document.getElementById('sample6_postcode').value = data.zonecode;
      document.getElementById("sample6_address").value = addr;
      // 커서를 상세주소 필드로 이동한다.
      document.getElementById("sample6_detailAddress").focus();
    }
  }).open();
}
