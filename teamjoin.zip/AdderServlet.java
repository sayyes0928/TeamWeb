import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class AdderServlet extends HttpServlet
{
	 public void doGet(HttpServletRequest request, HttpServletResponse response)
		 throws IOException, ServletException
	{ response.setContentType("text/html; charset=utf-8");
	   PrintWriter out = response.getWriter();
	   out.println("<html><head><title>���α׷�</title><head>");
	   out.println("<body>");
	   out.println("hello jsp");
	   out.println("</body></html>");
	  }
}
