import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class Logincookie extends HttpServlet
{
	 public void doGet(HttpServletRequest request, HttpServletResponse response)
		 throws IOException, ServletException
	{ 
		 response.setContentType("text/html; charset=utf-8");
	     
		 String id = request.getParameter("id");
		 String pwd = request.getParameter("pwd");
		 String checkbox = request.getParameter("checkbox");

	     PrintWriter out = response.getWriter();
		 
		 Cookie cookie = new Cookie("userid",id);

		 if(checkbox != null){
		   response.addCookie(cookie);
		 }else{
		   cookie.setMaxAge(0);
		   response.addCookie(cookie);
		  
		 }

		 if((id != null) && (pwd != null)){
		   if(id.equals("jsi0928") && pwd.equals("1234")){
			
		   }else{
			  
		     response.sendRedirect("loginCookiepage.jsp");
		   }
		 }

	  }
}