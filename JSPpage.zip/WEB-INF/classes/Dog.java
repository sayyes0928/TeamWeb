import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class Dog extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		response.setContentType("text/html; charset=utf-8");

		PrintWriter out = response.getWriter();

		String[]dogs = request.getParameterValues("dog");

		out.println("<html><head><title>dog</title></head>");
		out.println("<body>");
		out.println(dogs[0]);
		out.println(dogs.length);

		for(int i = 0 ; i < dogs.length; i++){
			out.println(dogs[i]);
		 if(dogs[i] == "dog1"){
			 out.println("<img src = './img/dog1.jpg'/>");
		 }
		 else if(dogs[i].equals("dog2")){
			 out.println("<img src = './img/dog2.jpg'/>");
		 }
		 else if(dogs[i].equals("dog3")){
			 out.println("<img src = './img/dog3.jpg'/>");
		 }
		 else if(dogs[i].equals("dog3")){
			 out.println("<img src = './img/dog4.jpg'/>");
		 }
		
		}
         
		
	

		out.println("</body></html>");

	}
}
