import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class AdderServlet extends HttpServlet
{
	 public void doGet(HttpServletRequest request, HttpServletResponse response)
		 throws IOException, ServletException
	{ response.setContentType("text/html; charset=utf-8");
	   PrintWriter out = response.getWriter();

	   int a = Integer.parseInt(request.getParameter("NUM1"));
	   int b = Integer.parseInt(request.getParameter("NUM2"));

	   int sum = (a+b);

	   out.println("<html><head><title>123123</title><head>");
	   out.println("<body>");
	   out.println("�� ������ ���� : " +sum+"�Դϴ�.<br>" );
	   out.println("</body></html>");

	  }
}
